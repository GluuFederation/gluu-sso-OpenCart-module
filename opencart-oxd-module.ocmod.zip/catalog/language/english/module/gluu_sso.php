<?php

// Heading
  $_['heading_title'] = 'OpenID Connect Single Sign-On (SSO) Extension by Gluu';

// Text
  $_['text_module'] = 'Module';
  $_['text_edit'] = 'Edit OpenID Connect Single Sign-On (SSO) Extension by Gluu';

  $_['gluu_sso'] = 'OpenID Connect Single Sign-On (SSO) Extension by Gluu';

?>